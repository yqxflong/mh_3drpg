var searchData=
[
  ['hasoutofboundsuvs',['hasOutOfBoundsUVs',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility.html#aaf57e4adcc51b3c693d923a796d14859',1,'DigitalOpus.MB.Core.MB_Utility.hasOutOfBoundsUVs(Mesh m, ref Rect uvBounds)'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility.html#a8bfe6f039d8ce8d7f530f74d4f26ba2b',1,'DigitalOpus.MB.Core.MB_Utility.hasOutOfBoundsUVs(Mesh m, ref Rect uvBounds, ref MeshAnalysisResult putResultHere, int submeshIndex=-1)']]]
];
