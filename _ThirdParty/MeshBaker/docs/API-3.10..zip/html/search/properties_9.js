var searchData=
[
  ['packingalgorithm',['packingAlgorithm',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner.html#a45f321e081f67ffec99b46d9bca9e321',1,'DigitalOpus.MB.Core.MB3_TextureCombiner.packingAlgorithm()'],['../class_m_b3___texture_baker.html#a1d40d7dc518b36c754c8343cda7c52e3',1,'MB3_TextureBaker.packingAlgorithm()']]]
];
