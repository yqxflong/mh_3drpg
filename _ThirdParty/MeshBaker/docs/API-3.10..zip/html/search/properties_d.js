var searchData=
[
  ['validationlevel',['validationLevel',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner.html#a0f758d463dca66d2310ac9152d165bd6',1,'DigitalOpus.MB.Core.MB3_MeshCombiner.validationLevel()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner.html#af22ad7445d912a0bd6f8273eee0388ca',1,'DigitalOpus.MB.Core.MB3_MultiMeshCombiner.validationLevel()']]]
];
