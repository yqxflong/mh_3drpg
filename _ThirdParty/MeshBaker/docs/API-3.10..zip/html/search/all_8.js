var searchData=
[
  ['hasoutofboundsuvs',['hasOutOfBoundsUVs',['../struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility_1_1_mesh_analysis_result.html#a534fe15fa2bf07593b12d2e8e3babbf1',1,'DigitalOpus.MB.Core.MB_Utility.MeshAnalysisResult.hasOutOfBoundsUVs()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility.html#aaf57e4adcc51b3c693d923a796d14859',1,'DigitalOpus.MB.Core.MB_Utility.hasOutOfBoundsUVs(Mesh m, ref Rect uvBounds)'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility.html#a8bfe6f039d8ce8d7f530f74d4f26ba2b',1,'DigitalOpus.MB.Core.MB_Utility.hasOutOfBoundsUVs(Mesh m, ref Rect uvBounds, ref MeshAnalysisResult putResultHere, int submeshIndex=-1)']]],
  ['hasoverlappingsubmeshtris',['hasOverlappingSubmeshTris',['../struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility_1_1_mesh_analysis_result.html#af713c0215fbbf0015b1dbb85342d01ba',1,'DigitalOpus::MB::Core::MB_Utility::MeshAnalysisResult']]],
  ['hasoverlappingsubmeshverts',['hasOverlappingSubmeshVerts',['../struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility_1_1_mesh_analysis_result.html#a8bab090d078ed2d51a5ed6e4aadfd948',1,'DigitalOpus::MB::Core::MB_Utility::MeshAnalysisResult']]]
];
